(function () {
  "use strict";

  var year = document.getElementById("year");
  if (year) year.textContent = String(new Date().getFullYear());

  var toggle = document.querySelector(".nav-toggle");
  var closeBtn = document.querySelector(".nav-close");
  var backdrop = document.getElementById("nav-backdrop");
  var nav = document.getElementById("site-nav");

  function setNavOpen(open) {
    if (!toggle || !nav) return;
    toggle.setAttribute("aria-expanded", open ? "true" : "false");
    toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    nav.classList.toggle("is-open", open);
    document.body.classList.toggle("nav-open", open);
    if (backdrop) {
      if (open) backdrop.removeAttribute("hidden");
      else backdrop.setAttribute("hidden", "");
    }
  }

  if (toggle) {
    toggle.addEventListener("click", function () {
      setNavOpen(toggle.getAttribute("aria-expanded") !== "true");
    });
  }

  if (closeBtn) {
    closeBtn.addEventListener("click", function () {
      setNavOpen(false);
    });
  }

  if (backdrop) {
    backdrop.addEventListener("click", function () {
      setNavOpen(false);
    });
  }

  if (nav) {
    nav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        setNavOpen(false);
        closeAllSubmenus();
      });
    });
  }

  function closeAllSubmenus() {
    document.querySelectorAll(".nav-item.has-submenu").forEach(function (item) {
      item.classList.remove("is-open");
      var btn = item.querySelector(".nav-submenu-toggle");
      if (btn) btn.setAttribute("aria-expanded", "false");
    });
  }

  document.querySelectorAll(".nav-submenu-toggle").forEach(function (btn) {
    btn.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();
      var item = btn.closest(".nav-item.has-submenu");
      if (!item) return;
      var willOpen = !item.classList.contains("is-open");
      closeAllSubmenus();
      if (willOpen) {
        item.classList.add("is-open");
        btn.setAttribute("aria-expanded", "true");
      }
    });
  });

  document.addEventListener("click", function (e) {
    if (!e.target.closest(".nav-item.has-submenu")) closeAllSubmenus();
  });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      setNavOpen(false);
      closeAllSubmenus();
    }
  });

  /* Hero slider */
  var slides = Array.prototype.slice.call(document.querySelectorAll(".hero-slide"));
  var dots = Array.prototype.slice.call(document.querySelectorAll(".hero-dot"));
  var index = 0;
  var timer = null;

  function goTo(i) {
    if (!slides.length) return;
    index = (i + slides.length) % slides.length;
    slides.forEach(function (slide, n) {
      slide.classList.toggle("is-active", n === index);
    });
    dots.forEach(function (dot, n) {
      dot.classList.toggle("is-active", n === index);
    });
  }

  function next() {
    goTo(index + 1);
  }

  function startAuto() {
    stopAuto();
    if (slides.length < 2) return;
    timer = window.setInterval(next, 6000);
  }

  function stopAuto() {
    if (timer) window.clearInterval(timer);
    timer = null;
  }

  dots.forEach(function (dot) {
    dot.addEventListener("click", function () {
      goTo(Number(dot.getAttribute("data-slide-to")));
      startAuto();
    });
  });

  var slider = document.querySelector("[data-slider]");
  if (slider) {
    slider.addEventListener("mouseenter", stopAuto);
    slider.addEventListener("mouseleave", startAuto);

    var touchStartX = 0;
    slider.addEventListener(
      "touchstart",
      function (e) {
        touchStartX = e.changedTouches[0].screenX;
        stopAuto();
      },
      { passive: true }
    );
    slider.addEventListener(
      "touchend",
      function (e) {
        var dx = e.changedTouches[0].screenX - touchStartX;
        if (Math.abs(dx) > 40) goTo(index + (dx < 0 ? 1 : -1));
        startAuto();
      },
      { passive: true }
    );
  }

  goTo(0);
  startAuto();

  /* Homepage hero slideshow */
  document.querySelectorAll("[data-gu-slider]").forEach(function (slider) {
    var slides = Array.prototype.slice.call(
      slider.querySelectorAll(".gu-hero-pro-slide, .gu-banner-slide, .gu-slide, .apc-hero-slide")
    );
    if (slides.length < 2) return;

    var dots = Array.prototype.slice.call(slider.querySelectorAll(".gu-dot"));
    var strips = Array.prototype.slice.call(slider.querySelectorAll(".gu-strip"));
    var prev = slider.querySelector("[data-gu-prev]");
    var nextBtn = slider.querySelector("[data-gu-next]");
    var progress = slider.querySelector(".gu-hero-progress > span");
    var i = 0;
    var t = null;
    var reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    function restartProgress() {
      if (!progress) return;
      slider.classList.remove("is-playing");
      void progress.offsetWidth;
      if (!reduced) slider.classList.add("is-playing");
    }

    function show(n) {
      i = (n + slides.length) % slides.length;
      slides.forEach(function (slide, idx) {
        slide.classList.toggle("is-active", idx === i);
      });
      dots.forEach(function (dot, idx) {
        dot.classList.toggle("is-active", idx === i);
      });
      strips.forEach(function (strip, idx) {
        strip.classList.toggle("is-active", idx === i);
      });
      restartProgress();
    }

    function play() {
      stop();
      if (reduced) return;
      restartProgress();
      t = window.setInterval(function () {
        show(i + 1);
      }, 5000);
    }

    function stop() {
      if (t) window.clearInterval(t);
      t = null;
      slider.classList.remove("is-playing");
    }

    dots.forEach(function (dot) {
      dot.addEventListener("click", function (e) {
        e.preventDefault();
        e.stopPropagation();
        show(Number(dot.getAttribute("data-gu-to")));
        play();
      });
    });

    strips.forEach(function (strip, idx) {
      strip.style.pointerEvents = "auto";
      strip.style.cursor = "pointer";
      strip.addEventListener("click", function () {
        show(idx);
        play();
      });
    });

    if (prev) {
      prev.addEventListener("click", function (e) {
        e.preventDefault();
        e.stopPropagation();
        show(i - 1);
        play();
      });
    }
    if (nextBtn) {
      nextBtn.addEventListener("click", function (e) {
        e.preventDefault();
        e.stopPropagation();
        show(i + 1);
        play();
      });
    }

    slider.addEventListener("mouseenter", stop);
    slider.addEventListener("mouseleave", play);

    var touchX = 0;
    slider.addEventListener(
      "touchstart",
      function (e) {
        touchX = e.changedTouches[0].screenX;
        stop();
      },
      { passive: true }
    );
    slider.addEventListener(
      "touchend",
      function (e) {
        var dx = e.changedTouches[0].screenX - touchX;
        if (Math.abs(dx) > 40) show(i + (dx < 0 ? 1 : -1));
        play();
      },
      { passive: true }
    );

    document.addEventListener("visibilitychange", function () {
      if (document.hidden) stop();
      else play();
    });

    show(0);
    play();
  });

  /* Sticky header scrolled state */
  var siteHeader = document.getElementById("site-header");
  if (siteHeader) {
    var onScrollHeader = function () {
      siteHeader.classList.toggle("is-scrolled", window.scrollY > 8);
    };
    onScrollHeader();
    window.addEventListener("scroll", onScrollHeader, { passive: true });
  }

  /* Scroll reveal */
  var revealEls = document.querySelectorAll(".gu-reveal");
  if (revealEls.length && "IntersectionObserver" in window) {
    var revealObs = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-in");
            revealObs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );
    revealEls.forEach(function (el) {
      revealObs.observe(el);
    });
  } else {
    revealEls.forEach(function (el) {
      el.classList.add("is-in");
    });
  }

  /* Soft hero parallax on pointer move */
  var heroPro = document.querySelector(".gu-hero-pro");
  if (heroPro && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    var frame = heroPro.querySelector(".gu-hero-pro-slide.is-active .gu-hero-visual-frame");
    heroPro.addEventListener(
      "pointermove",
      function (e) {
        var rect = heroPro.getBoundingClientRect();
        var x = (e.clientX - rect.left) / rect.width - 0.5;
        var y = (e.clientY - rect.top) / rect.height - 0.5;
        frame = heroPro.querySelector(".gu-hero-pro-slide.is-active .gu-hero-visual-frame");
        if (!frame) return;
        frame.style.transform =
          "translate(" + (x * 10) + "px, " + (y * 8) + "px) scale(1.01)";
      },
      { passive: true }
    );
    heroPro.addEventListener("pointerleave", function () {
      frame = heroPro.querySelector(".gu-hero-pro-slide.is-active .gu-hero-visual-frame");
      if (frame) frame.style.transform = "";
    });
  }

  /* FAQ: only one open at a time */
  document.querySelectorAll(".gu-faq-item").forEach(function (item) {
    item.addEventListener("toggle", function () {
      if (!item.open) return;
      document.querySelectorAll(".gu-faq-item").forEach(function (other) {
        if (other !== item) other.open = false;
      });
    });
  });

  /* Lead submission → Google Apps Script (Sheet + email to Ghar Upgrade inboxes) */
  var LEAD_ENDPOINT =
    "https://script.google.com/macros/s/AKfycbwZsmVWXwgwKq6gJnGTGTtW1lYaoFq6JsgcUI5bjWahNHOfYF7CzaHQW-nEHi2f_on-/exec";

  function getLeadStatusEl(form) {
    var el = form.querySelector("[data-lead-status]");
    if (!el) {
      el = document.createElement("p");
      el.className = "form-hint";
      el.setAttribute("data-lead-status", "");
      el.setAttribute("role", "status");
      el.setAttribute("aria-live", "polite");
      form.appendChild(el);
    }
    return el;
  }

  var LEAD_DEDUPE_MS = 24 * 60 * 60 * 1000;
  var FAKE_NAMES = /^(test|testing|asdf|qwerty|abc|abcd|xyz|fake|demo|sample|none|na|n\/a|null|admin|user|name|aaa+|xxx+)$/i;
  var FAKE_EMAIL_USERS = /^(admin|test|testing|demo|fake|sample|abc|xyz|asdf|qwerty|none|null|noreply|no-reply|example|user|info|mail|email)\d*$/i;
  var FAKE_EMAIL_DOMAINS = /(^|\.)(example\.(com|org|net)|test\.com|domain\.com|email\.com|mailinator\.com|yopmail\.com|tempmail\.com|temp-mail\.org|guerrillamail\.com|10minutemail\.com|trashmail\.com|sharklasers\.com|fakeinbox\.com|getnada\.com|dispostable\.com)$/i;

  function toIndianMobile(raw) {
    var d = String(raw || "").replace(/\D/g, "");
    if (d.length === 12 && d.indexOf("91") === 0) d = d.slice(2);
    else if (d.length === 11 && d.charAt(0) === "0") d = d.slice(1);
    return d;
  }

  function phoneError(raw) {
    var d = toIndianMobile(raw);
    if (d.length !== 10) return "Enter a valid 10-digit mobile number.";
    if (!/^[6-9]/.test(d)) return "Mobile number should start with 6, 7, 8 or 9.";
    if (/^(\d)\1{9}$/.test(d)) return "Please enter your real mobile number.";
    if ("01234567890123456789".indexOf(d) !== -1 || "98765432109876543210".indexOf(d) !== -1) {
      return "Please enter your real mobile number.";
    }
    var unique = {};
    for (var i = 0; i < d.length; i++) unique[d.charAt(i)] = true;
    if (Object.keys(unique).length < 3) return "Please enter your real mobile number.";
    return "";
  }

  function emailError(raw) {
    var v = String(raw || "").trim().toLowerCase();
    if (!v) return "";
    if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/.test(v)) return "Enter a valid email address.";
    var parts = v.split("@");
    if (FAKE_EMAIL_USERS.test(parts[0]) || FAKE_EMAIL_DOMAINS.test(parts[1])) {
      return "Please use your personal email address.";
    }
    return "";
  }

  function nameError(raw) {
    var v = String(raw || "").trim();
    if (v.replace(/[^A-Za-z]/g, "").length < 2) return "Please enter your full name.";
    if (!/^[A-Za-z][A-Za-z .'-]*$/.test(v)) return "Name should contain letters only.";
    if (FAKE_NAMES.test(v.replace(/\s+/g, ""))) return "Please enter your real name.";
    return "";
  }

  function validateLead(data) {
    var err = nameError(data.name);
    if (err) return { field: "name", message: err };
    err = phoneError(data.phone);
    if (err) return { field: "phone", message: err };
    if (data.email) {
      err = emailError(data.email);
      if (err) return { field: "email", message: err };
    }
    if (data.pincode && !/^[1-9]\d{5}$/.test(String(data.pincode).trim())) {
      return { field: "pincode", message: "Enter a valid 6-digit pincode." };
    }
    return null;
  }

  function wasRecentlySubmitted(mobile) {
    try {
      var seen = JSON.parse(localStorage.getItem("gu_leads") || "{}");
      return seen[mobile] && Date.now() - seen[mobile] < LEAD_DEDUPE_MS;
    } catch (err) {
      return false;
    }
  }

  function rememberSubmission(mobile) {
    try {
      var seen = JSON.parse(localStorage.getItem("gu_leads") || "{}");
      seen[mobile] = Date.now();
      localStorage.setItem("gu_leads", JSON.stringify(seen));
    } catch (err) {}
  }

  document.querySelectorAll('input[name="phone"]').forEach(function (input) {
    input.setAttribute("inputmode", "numeric");
    input.setAttribute("autocomplete", "tel-national");
    input.removeAttribute("maxlength");
    if (/X{5}/.test(input.getAttribute("placeholder") || "")) {
      input.setAttribute("placeholder", "10-digit mobile number");
    }
    input.addEventListener("input", function () {
      var d = toIndianMobile(input.value);
      if (input.value !== d.slice(0, 10)) input.value = d.slice(0, 10);
    });
  });

  document.querySelectorAll('input[name="pincode"]').forEach(function (input) {
    input.setAttribute("inputmode", "numeric");
    input.setAttribute("maxlength", "6");
    input.addEventListener("input", function () {
      var d = input.value.replace(/\D/g, "").slice(0, 6);
      if (input.value !== d) input.value = d;
    });
  });

  function submitLead(form, data, statusEl, onSuccess) {
    var status = statusEl || getLeadStatusEl(form);

    var invalid = validateLead(data);
    if (invalid) {
      status.textContent = invalid.message;
      var badField = form.querySelector('[name="' + invalid.field + '"]');
      if (badField) badField.focus();
      return;
    }

    var mobile = toIndianMobile(data.phone);
    data.phone = "+91 " + mobile.slice(0, 5) + " " + mobile.slice(5);
    if (wasRecentlySubmitted(mobile)) {
      status.textContent =
        "We already have your request from this number — our team will call you shortly.";
      return;
    }

    var btn = form.querySelector('[type="submit"]');
    var btnText = btn ? btn.textContent : "";
    if (btn) {
      btn.disabled = true;
      btn.textContent = "Sending…";
    }
    status.textContent = "Sending your details…";

    data.page_url = window.location.href;
    var body = new URLSearchParams();
    Object.keys(data).forEach(function (key) {
      var val = data[key];
      if (val !== undefined && val !== null && String(val).trim() !== "") {
        body.append(key, String(val).trim());
      }
    });

    /* no-cors: Apps Script redirects, so the response is opaque — a resolved fetch means it was delivered */
    fetch(LEAD_ENDPOINT, { method: "POST", mode: "no-cors", body: body })
      .then(function () {
        rememberSubmission(mobile);
        status.textContent =
          "Thank you! Our Ghar Upgrade team will contact you shortly.";
        form.reset();
        if (typeof onSuccess === "function") onSuccess();
      })
      .catch(function () {
        status.textContent =
          "Couldn’t send right now. Please call or WhatsApp us, or try again.";
      })
      .then(function () {
        if (btn) {
          btn.disabled = false;
          btn.textContent = btnText;
        }
      });
  }

  function fieldVal(form, name) {
    var el = form.querySelector('[name="' + name + '"]');
    return el ? el.value || "" : "";
  }

  function checkedVal(form, name) {
    var el = form.querySelector('[name="' + name + '"]');
    if (!el) return "";
    return el.checked ? "Yes" : "No";
  }

  window.guSubmitLead = submitLead;
  window.guCheckedVal = checkedVal;

  /* Quote popup */
  var quoteModal = document.getElementById("quote-modal");
  var quoteForm = document.getElementById("quote-modal-form");
  var quoteService = document.getElementById("quote-service");
  var quoteStatus = document.getElementById("quote-form-status");
  var lastFocus = null;

  function openQuote(service) {
    if (!quoteModal) return;
    lastFocus = document.activeElement;
    quoteModal.hidden = false;
    document.body.classList.add("quote-open");
    setNavOpen(false);
    if (quoteService) {
      quoteService.value = service || "";
    }
    if (quoteStatus) {
      quoteStatus.textContent =
        "We’ll call you back within business hours.";
    }
    var first = quoteModal.querySelector("input, select, textarea, button");
    if (first) first.focus();
  }

  function closeQuote() {
    if (!quoteModal) return;
    quoteModal.hidden = true;
    document.body.classList.remove("quote-open");
    if (lastFocus && typeof lastFocus.focus === "function") lastFocus.focus();
  }

  document.addEventListener("click", function (e) {
    var trigger = e.target.closest("[data-open-quote]");
    if (trigger) {
      e.preventDefault();
      openQuote(trigger.getAttribute("data-service") || "");
      return;
    }
    if (e.target.closest("[data-close-quote]")) {
      e.preventDefault();
      closeQuote();
    }
  });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && quoteModal && !quoteModal.hidden) {
      closeQuote();
    }
  });

  if (quoteForm) {
    quoteForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var service = fieldVal(quoteForm, "service");
      submitLead(
        quoteForm,
        {
          name: fieldVal(quoteForm, "name"),
          phone: fieldVal(quoteForm, "phone"),
          email: fieldVal(quoteForm, "email"),
          locality: fieldVal(quoteForm, "locality"),
          service: service,
          message: fieldVal(quoteForm, "message"),
          source: "quote-popup",
        },
        quoteStatus,
        function () {
          if (quoteService && service) quoteService.value = service;
          window.setTimeout(closeQuote, 1800);
        }
      );
    });
  }

  var wpConsult = document.getElementById("wp-consult-form");
  var wpConsultStatus = document.getElementById("wp-consult-status");
  if (wpConsult) {
    wpConsult.addEventListener("submit", function (e) {
      e.preventDefault();
      submitLead(
        wpConsult,
        {
          name: fieldVal(wpConsult, "name"),
          phone: fieldVal(wpConsult, "phone"),
          pincode: fieldVal(wpConsult, "pincode"),
          address: fieldVal(wpConsult, "address"),
          service: "Waterproofing",
          need: fieldVal(wpConsult, "need"),
          timeline: fieldVal(wpConsult, "timeline"),
          painter: fieldVal(wpConsult, "painter"),
          source: "waterproofing-consultation",
        },
        wpConsultStatus
      );
    });
  }

  var idConsult = document.getElementById("id-consult-form");
  var idConsultStatus = document.getElementById("id-consult-status");
  if (idConsult) {
    idConsult.addEventListener("submit", function (e) {
      e.preventDefault();
      submitLead(
        idConsult,
        {
          name: fieldVal(idConsult, "name"),
          phone: fieldVal(idConsult, "phone"),
          pincode: fieldVal(idConsult, "pincode"),
          address: fieldVal(idConsult, "address"),
          service: "Interior Design",
          need: fieldVal(idConsult, "need"),
          interest: fieldVal(idConsult, "interest"),
          source: "interior-consultation",
        },
        idConsultStatus
      );
    });
  }

  var contactForm = document.getElementById("contact-form");
  if (contactForm) {
    contactForm.addEventListener("submit", function (e) {
      e.preventDefault();
      submitLead(contactForm, {
        name: fieldVal(contactForm, "name"),
        phone: fieldVal(contactForm, "phone"),
        email: fieldVal(contactForm, "email"),
        locality: fieldVal(contactForm, "locality"),
        service: fieldVal(contactForm, "service"),
        message: fieldVal(contactForm, "message"),
        whatsapp: checkedVal(contactForm, "whatsapp"),
        source: "contact-form",
      });
    });
  }

  /* Lead hero site-inspection forms */
  document.querySelectorAll("[data-lead-form]").forEach(function (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var service = form.getAttribute("data-service") || "Site inspection";
      var timelineEl = form.querySelector('[name="timeline"]:checked');
      var painterEl = form.querySelector('[name="painter"]:checked');
      submitLead(form, {
        name: fieldVal(form, "name"),
        phone: fieldVal(form, "phone"),
        address: fieldVal(form, "address"),
        pincode: fieldVal(form, "pincode"),
        service: service,
        need: fieldVal(form, "need"),
        whatsapp: checkedVal(form, "whatsapp"),
        timeline: timelineEl ? timelineEl.value : "",
        painter: painterEl ? painterEl.value : "",
        source: "site-inspection-" + service.toLowerCase().replace(/\s+/g, "-"),
      });
    });
  });

  /* Painting process tabs (legacy) */
  var processTabs = document.querySelectorAll("[data-process-tab]");
  if (processTabs.length) {
    processTabs.forEach(function (tab) {
      tab.addEventListener("click", function () {
        var id = tab.getAttribute("data-process-tab");
        processTabs.forEach(function (t) {
          var on = t === tab;
          t.classList.toggle("is-active", on);
          t.setAttribute("aria-selected", on ? "true" : "false");
        });
        document.querySelectorAll("[data-process-panel]").forEach(function (panel) {
          var show = panel.getAttribute("data-process-panel") === id;
          if (show) panel.removeAttribute("hidden");
          else panel.setAttribute("hidden", "");
        });
      });
    });
  }

  /* FAQ: only one open at a time */
  document.querySelectorAll("[data-faq]").forEach(function (root) {
    root.querySelectorAll("details").forEach(function (item) {
      item.addEventListener("toggle", function () {
        if (!item.open) return;
        root.querySelectorAll("details").forEach(function (other) {
          if (other !== item) other.open = false;
        });
      });
    });
  });

  /* Floating quote tab: show after first scroll, hide over the footer */
  var quoteTab = document.querySelector(".quote-tab");
  if (quoteTab) {
    var footerEl = document.querySelector(".site-footer");
    var updateQuoteTab = function () {
      var scrolled = window.scrollY > 240;
      var overFooter = footerEl && footerEl.getBoundingClientRect().top < window.innerHeight * 0.6;
      quoteTab.classList.toggle("is-visible", scrolled && !overFooter);
    };
    window.addEventListener("scroll", updateQuoteTab, { passive: true });
    window.addEventListener("resize", updateQuoteTab);
    updateQuoteTab();
  }

  /* Before / after drag sliders */
  document.querySelectorAll("[data-ba-slider]").forEach(function (slider) {
    var range = slider.querySelector(".ba-range");
    var dragging = false;

    var setPos = function (pct) {
      pct = Math.max(0, Math.min(100, pct));
      slider.style.setProperty("--pos", pct + "%");
      slider.dataset.near = pct < 15 ? "left" : pct > 85 ? "right" : "";
      if (range) range.value = String(Math.round(pct));
    };

    var fromEvent = function (e) {
      var rect = slider.getBoundingClientRect();
      setPos(((e.clientX - rect.left) / rect.width) * 100);
    };

    slider.addEventListener("pointerdown", function (e) {
      dragging = true;
      slider.classList.remove("is-hinting");
      slider.classList.add("is-dragging");
      slider.setPointerCapture(e.pointerId);
      fromEvent(e);
      if (range) range.focus({ preventScroll: true });
    });
    slider.addEventListener("pointermove", function (e) {
      if (dragging) fromEvent(e);
    });
    var stop = function () {
      dragging = false;
      slider.classList.remove("is-dragging");
    };
    slider.addEventListener("pointerup", stop);
    slider.addEventListener("pointercancel", stop);

    if (range) {
      range.addEventListener("input", function () {
        setPos(Number(range.value));
      });
    }

    if ("IntersectionObserver" in window && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) return;
          io.disconnect();
          slider.classList.add("is-hinting");
          setPos(30);
          setTimeout(function () { if (!dragging) setPos(70); }, 650);
          setTimeout(function () {
            if (!dragging) setPos(50);
            setTimeout(function () { slider.classList.remove("is-hinting"); }, 650);
          }, 1300);
        });
      }, { threshold: 0.6 });
      io.observe(slider);
    }
  });
})();
